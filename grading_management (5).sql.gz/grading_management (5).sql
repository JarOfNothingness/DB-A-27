-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2024 at 06:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grading management`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` enum('Present','Absent','Late') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `class_records`
--

CREATE TABLE `class_records` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `written_exam` decimal(5,2) DEFAULT NULL,
  `performance_task` decimal(5,2) DEFAULT NULL,
  `quarterly_exam` decimal(5,2) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `empt_table`
--

CREATE TABLE `empt_table` (
  `id` int(11) NOT NULL,
  `username` varchar(36) NOT NULL,
  `email` varchar(36) NOT NULL,
  `password` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `empt_table`
--

INSERT INTO `empt_table` (`id`, `username`, `email`, `password`) VALUES
(1, 'Gorlock', 'gorlock@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `final_grades`
--

CREATE TABLE `final_grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `form14_final_grades`
--

CREATE TABLE `form14_final_grades` (
  `form14Id` int(11) NOT NULL,
  `schoolName` varchar(255) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `firstQuarterGrade` int(11) DEFAULT NULL,
  `secondQuarterGrade` int(11) DEFAULT NULL,
  `thirdQuarterGrade` int(11) DEFAULT NULL,
  `fourthQuarterGrade` int(11) DEFAULT NULL,
  `finalGrade` int(11) DEFAULT NULL,
  `totalScore` int(11) DEFAULT NULL,
  `highestPossibleScore` int(11) DEFAULT NULL,
  `highestScore` int(11) DEFAULT NULL,
  `lowestScore` int(11) DEFAULT NULL,
  `averageMean` int(11) DEFAULT NULL,
  `mps` int(11) DEFAULT NULL,
  `numStudentsGetting75PL` int(11) DEFAULT NULL,
  `percentageOfStudentsGetting75PL` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `form137_card`
--

CREATE TABLE `form137_card` (
  `form137Id` int(11) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `teacherName` varchar(100) NOT NULL,
  `schoolId` int(11) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `written_exam` decimal(5,2) DEFAULT NULL,
  `performance_task` decimal(5,2) DEFAULT NULL,
  `quarterly_exam` decimal(5,2) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pending_list`
--

CREATE TABLE `pending_list` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL,
  `form_2` varchar(255) DEFAULT NULL,
  `form_137` varchar(255) DEFAULT NULL,
  `form_14` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `alert_sent` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `teacher_id`, `title`, `description`, `start_time`, `end_time`, `alert_sent`) VALUES
(1, 4, 'Orientation', 'Teachers meeting', '2024-08-01 17:58:00', '2024-08-01 18:00:00', 0),
(2, 6, 'wdasdasdsasdasdas', 'asdasd', '2024-08-09 19:28:00', '2024-08-01 07:33:00', 0),
(5, 35, 'Science ', 'Class', '2024-08-22 09:00:00', '2024-08-22 10:00:00', 0),
(10, 10, 'Test', '1', '2024-08-25 13:49:00', '2024-08-25 20:50:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sf2_attendance_report`
--

CREATE TABLE `sf2_attendance_report` (
  `form2Id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `learnerAttendanceConversionTool` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `month` varchar(20) NOT NULL,
  `day_01` char(1) DEFAULT NULL,
  `day_02` char(1) DEFAULT NULL,
  `day_03` char(1) DEFAULT NULL,
  `day_04` char(1) DEFAULT NULL,
  `day_05` char(1) DEFAULT NULL,
  `day_06` char(1) DEFAULT NULL,
  `day_07` char(1) DEFAULT NULL,
  `day_08` char(1) DEFAULT NULL,
  `day_09` char(1) DEFAULT NULL,
  `day_10` char(1) DEFAULT NULL,
  `day_11` char(1) DEFAULT NULL,
  `day_12` char(1) DEFAULT NULL,
  `day_13` char(1) DEFAULT NULL,
  `day_14` char(1) DEFAULT NULL,
  `day_15` char(1) DEFAULT NULL,
  `day_16` char(1) DEFAULT NULL,
  `day_17` char(1) DEFAULT NULL,
  `day_18` char(1) DEFAULT NULL,
  `day_19` char(1) DEFAULT NULL,
  `day_20` char(1) DEFAULT NULL,
  `day_21` char(1) DEFAULT NULL,
  `day_22` char(1) DEFAULT NULL,
  `day_23` char(1) DEFAULT NULL,
  `day_24` char(1) DEFAULT NULL,
  `day_25` char(1) DEFAULT NULL,
  `day_26` char(1) DEFAULT NULL,
  `day_27` char(1) DEFAULT NULL,
  `day_28` char(1) DEFAULT NULL,
  `day_29` char(1) DEFAULT NULL,
  `day_30` char(1) DEFAULT NULL,
  `day_31` char(1) DEFAULT NULL,
  `total_present` int(11) DEFAULT NULL,
  `total_absent` int(11) DEFAULT NULL,
  `total_late` int(11) DEFAULT NULL,
  `total_excused` int(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sf2_attendance_report`
--

INSERT INTO `sf2_attendance_report` (`form2Id`, `schoolId`, `learnerName`, `gradeLevel`, `learnerAttendanceConversionTool`, `section`, `schoolYear`, `month`, `day_01`, `day_02`, `day_03`, `day_04`, `day_05`, `day_06`, `day_07`, `day_08`, `day_09`, `day_10`, `day_11`, `day_12`, `day_13`, `day_14`, `day_15`, `day_16`, `day_17`, `day_18`, `day_19`, `day_20`, `day_21`, `day_22`, `day_23`, `day_24`, `day_25`, `day_26`, `day_27`, `day_28`, `day_29`, `day_30`, `day_31`, `total_present`, `total_absent`, `total_late`, `total_excused`, `remarks`) VALUES
(20, 209766, 'Kiara', '7th', '', 'Section A', '2020', '2024-08', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `learners_name` varchar(255) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `division` varchar(100) DEFAULT NULL,
  `school_id` varchar(100) DEFAULT NULL,
  `school_year` varchar(20) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `section` varchar(36) NOT NULL,
  `grade` varchar(36) NOT NULL,
  `school_level` varchar(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `learners_name`, `region`, `division`, `school_id`, `school_year`, `gender`, `subject`, `section`, `grade`, `school_level`, `user_id`) VALUES
(20248077, 'Kiara', 'VII', 'CEBU', '209766', '2020', 'Female', 'English', 'Section A', '7th', 'JHS', NULL),
(20248087, 'Josh Lim', 'VII', 'CEBU', '207590', '2021', 'Male', 'Advanced Science', 'Section X', '11th', 'SHS', NULL),
(20248088, 'Test', 'VII', 'CEBU', '200361', '2020', 'Male', 'Advanced Math', 'Section Y', '12th', 'SHS', NULL),
(20248090, 'Gabriel', 'VII', 'CEBU', '208806', '2021', 'Male', 'Science', 'Section A', '10th', 'JHS', NULL),
(20248091, 'Degoma', 'VII', 'CEBU', '206784', '2020', 'Female', 'PE', 'Section B', '8th', 'JHS', NULL),
(20248092, 'Anna Special', 'VII', 'CEBU', '203170', '2020', 'Female', 'Economics', 'Section X', '11th', 'SHS', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_grades`
--

CREATE TABLE `student_grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `written_exam` float DEFAULT NULL,
  `performance_task` float DEFAULT NULL,
  `quarterly_exam` float DEFAULT NULL,
  `final_grade` float DEFAULT NULL,
  `highest_possible_score` decimal(5,2) DEFAULT NULL,
  `lowest_score` decimal(5,2) DEFAULT NULL,
  `average_mean` decimal(5,2) DEFAULT NULL,
  `mps` decimal(5,2) DEFAULT NULL,
  `students_75_percent` int(11) DEFAULT NULL,
  `percentage_75_percent` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_grades`
--

INSERT INTO `student_grades` (`id`, `student_id`, `subject_id`, `written_exam`, `performance_task`, `quarterly_exam`, `final_grade`, `highest_possible_score`, `lowest_score`, `average_mean`, `mps`, `students_75_percent`, `percentage_75_percent`) VALUES
(34, 20248077, 1, 92, 89, 88, 89.7, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `description`, `student_id`) VALUES
(1, 'Mathematics', 'Math course description', NULL),
(2, 'English', 'English course description', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `name` varchar(36) NOT NULL,
  `username` varchar(36) NOT NULL,
  `password` varchar(36) NOT NULL,
  `address` varchar(36) NOT NULL,
  `role` varchar(36) NOT NULL,
  `confirm_password` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `username`, `password`, `address`, `role`, `confirm_password`, `status`) VALUES
(8, 'moses', 'mm', '12', 'moses@gmail.com', 'Teacher', '', 'approved'),
(9, 'Marlyn', 'Marlyn@gmail.com', '123', 'Marlyn@gmail.com', 'Admin', '', 'approved'),
(10, 'Anna', 'Anna', 'summer', 'Anna@gmail.com', 'Teacher', '', 'approved'),
(11, 'Els', 'els', 'snowqueen', 'els@gmail.com', 'Teacher', '', 'approved'),
(12, 'Jose', 'JN', '123', 'Jose@gmail.com', 'Admin', '', 'approved'),
(14, 'Jake Serotonin', 'jake', '123', 'jakeS@gmail.com', 'Teacher', '123', 'approved'),
(16, 'asd', 'asd', '1234', 'asd@gmail', 'Teacher', '', 'approved'),
(17, 'asd', 'asd', '1234', 'asd@gmail', 'Teacher', '123', 'approved'),
(23, 'Kristine', 'Kristine', '123', 'Kristine@gmail.com', 'Teacher', '123', 'approved'),
(31, 'Faith', 'Fathima123', 'fathima123', 'Fathima@gmail.com', 'Teacher', 'fathima123', 'approved'),
(35, 'Moses Mae', 'mmae.123', 'moses@123', 'moses@gmail.com', 'Teacher', 'moses@123', 'approved'),
(36, 'Melvic', 'Melvicgreg123', 'melvicgregg123', 'melvicgregg@gmail.com', 'Teacher', 'melvicgregg123', 'approved'),
(38, 'Joanna', 'JoannaMary123', '$2y$10$5cgduyhT.KukV7ZaI2sqt.sz6FWoK', 'Joannababy@gmail.com', 'Teacher', 'Maryjoana123', 'approved'),
(39, 'Testing', 'testing12345', 'db7f58f20646ac82', 'testing@gmail.com', 'Teacher', '', ''),
(40, 'Testing', 'testing12345', '$2y$10$z1xcuhBrXRoQnWuIqQnRReeGIw3n2', 'testing@gmail.com', 'Teacher', '', 'approved'),
(41, 'Testing', 'testing123', '$2y$10$xG6pU5X.YcwRR3ZBP7WKbON2VDi54', 'testing@gmail.com', 'Teacher', '', 'approved'),
(42, 'Hope', 'Hope123', '93429c1de7d67c2a', 'Hope@gmail.com', 'Teacher', '', 'approved'),
(43, 'Hope', 'Hope123', '592ce79a93a91444', 'Hope@gmail.com', 'Teacher', '', 'approved'),
(44, 'Hope', 'hope123', 'ddcbe7df437d9d52', 'Hope@gmail.com', 'Teacher', '', 'approved'),
(45, 'Hope', 'Hope123', 'de66d8bc9653f612', 'Hope@gmail.com', 'Teacher', '', 'approved'),
(46, 'Hope', 'Hope123', '90bd3b8491ec233a', 'Hope@gmail123', 'Teacher', '', 'approved'),
(47, 'Hope', 'Hope123', '0a5a7e5c095f9991', 'Hope@gmail123', 'Teacher', '', 'approved'),
(48, 'Hope', 'Hope123', 'db37352e501b087f', 'Hope@gmail123', 'Teacher', '', 'approved'),
(51, 'Joanna', 'joannabel', 'joannabel123', 'Joanna@gmail.com', 'Teacher', '', 'approved'),
(53, 'Kid', 'Akidz123', '855361bf75b81bd4', 'Akid@gmail.com', 'Teacher', '', 'approved'),
(58, 'Joel Caesar', 'Joel123', '4d4d554ac37e21cb', 'JoelC@gmail.com', 'Teacher', '', 'approved'),
(59, 'Joel Caesar', 'Joel1234', '76fd7b01b8b833be', 'JoelC@gmail.com', 'Teacher', '', 'approved'),
(61, 'Montana', 'montana123', '86dd09ece0e9bdb7', 'montana@gmail.com', 'Teacher', '', 'approved'),
(65, 'Montana', 'montana123', '6ab10a4117e7f093', 'montana@gmail.com', 'Teacher', '', 'approved'),
(66, 'Pleasework', 'pleasework123', '173861b3af42cc95', 'pleasework@work', 'Teacher', '', 'approved'),
(67, 'Ajax', 'ajax123', 'e79cd9d7aa1d0ab1', 'ajax@gmail.com', 'Teacher', '', 'approved'),
(68, 'Fathima', 'Fathima123', '$2y$10$97DydBvZK1UtABb9gvoaneGdZF2a/', 'fathima@gmail.com', 'Teacher', '', ''),
(69, 'Kratos', 'kratos123', '6f2d01b3323cfce3', 'kratos@gmail.com', 'Teacher', '', 'approved'),
(70, 'Kratos', 'kratos123', '', 'kratos@gmail.com', 'Teacher', '', ''),
(71, 'Testing123', 'testing321', '0214fb9497e8a052', '123testing@gmail.com', 'Teacher', '', 'approved'),
(72, 'Testing123', 'testing321', 'jordanclarkson123', '123testing@gmail.com', 'Teacher', '', ''),
(73, 'PeterLang', 'Peter123', 'petero', 'Peterlang@gmail.com', 'Teacher', '', ''),
(74, 'Test90', 'Test90', 'test', 'test90@g', 'Teacher', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_activity_log`
--

CREATE TABLE `user_activity_log` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_activity_log`
--

INSERT INTO `user_activity_log` (`id`, `username`, `action`, `timestamp`) VALUES
(1, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:04'),
(2, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05'),
(3, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05'),
(4, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05'),
(5, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05'),
(6, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:06'),
(7, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:09'),
(8, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:11'),
(9, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:13'),
(10, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:15'),
(11, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:22'),
(12, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:49:08'),
(13, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:49:11'),
(14, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:28'),
(15, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:31'),
(16, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:36'),
(17, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:52:13'),
(18, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:26'),
(19, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:30'),
(20, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:53'),
(21, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:53'),
(22, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:55:26'),
(23, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:57:59'),
(24, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:01:18'),
(25, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:01:34'),
(26, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:03:20'),
(27, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:03:44'),
(28, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:05:33'),
(29, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:08:58'),
(30, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:09:03'),
(31, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:18:02'),
(32, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:16'),
(33, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:23'),
(34, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:33'),
(35, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:23:55'),
(36, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:37'),
(37, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:39'),
(38, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:42'),
(39, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:44'),
(40, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:59'),
(41, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:26:05'),
(42, 'admin', 'Accessed Admin Homepage', '2024-08-20 09:29:08'),
(43, 'user1', 'Logged In', '2024-08-20 09:29:08'),
(44, 'user2', 'Updated Profile', '2024-08-20 09:29:08'),
(45, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:31:09'),
(46, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:13'),
(47, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:13'),
(48, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:15'),
(49, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:48'),
(50, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:36:13'),
(51, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:36:18'),
(52, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10'),
(53, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10'),
(54, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10'),
(55, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:13'),
(56, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:15'),
(57, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:17'),
(58, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37'),
(59, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37'),
(60, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37'),
(61, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:09'),
(62, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:47'),
(63, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:51'),
(64, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `class_records`
--
ALTER TABLE `class_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `empt_table`
--
ALTER TABLE `empt_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `final_grades`
--
ALTER TABLE `final_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `form14_final_grades`
--
ALTER TABLE `form14_final_grades`
  ADD PRIMARY KEY (`form14Id`);

--
-- Indexes for table `form137_card`
--
ALTER TABLE `form137_card`
  ADD PRIMARY KEY (`form137Id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `pending_list`
--
ALTER TABLE `pending_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sf2_attendance_report`
--
ALTER TABLE `sf2_attendance_report`
  ADD PRIMARY KEY (`form2Id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD PRIMARY KEY (`student_id`,`subject_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_student_subject` (`student_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `class_records`
--
ALTER TABLE `class_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `empt_table`
--
ALTER TABLE `empt_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `final_grades`
--
ALTER TABLE `final_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `form14_final_grades`
--
ALTER TABLE `form14_final_grades`
  MODIFY `form14Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `form137_card`
--
ALTER TABLE `form137_card`
  MODIFY `form137Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pending_list`
--
ALTER TABLE `pending_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sf2_attendance_report`
--
ALTER TABLE `sf2_attendance_report`
  MODIFY `form2Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20248094;

--
-- AUTO_INCREMENT for table `student_grades`
--
ALTER TABLE `student_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `class_records`
--
ALTER TABLE `class_records`
  ADD CONSTRAINT `class_records_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `final_grades`
--
ALTER TABLE `final_grades`
  ADD CONSTRAINT `final_grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD CONSTRAINT `student_grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `student_grades_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD CONSTRAINT `student_subject_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_subject_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `fk_student_subject` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
